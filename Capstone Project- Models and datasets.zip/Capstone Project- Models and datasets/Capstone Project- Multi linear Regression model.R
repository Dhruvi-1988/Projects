#Capstone Project 

#COVID-19 MORTALITY IN ASSOCIATION WITH PRESENCE OF COMORBIDITIES,FULLY VACCINATED, AT LEAST ONE DOSE VACCINATED AND PARTIALLY VACCINATED POPULATION

# MUltilinear regression model using R Studio.

```{r setup, include=FALSE}
knitr::opts_chunk$set(echo = TRUE)
install.packages(pkgs = c( "dplyr", "ggplot2", "ggformula", "mosaic", "supernova", "lsr"))
library("readr")
library("data.table")
library("mosaic")
library("dplyr")
library("ggplot2")
library("ggformula")
library("supernova")
library("lsr")
library("esquisse")
library("tidyverse")
library("shiny")
library("forcats")
library("plotly")
library("ggpubr")
library("broom")
library("AICcmodavg")
library("tidyr")

myDataLocation <- "C:\\Users\\Pandits\\Desktop\\699B datasets\\California\\San diego"

#SET WORKING DIRECTORY TO LOCATION OF DATA FILE
setwd(myDataLocation)

#Imported Sandiego cases and death dataset
myData1 <- read.csv(file = file.path(myDataLocation,"California county data_cases_death-new.csv"),header = TRUE)
summary(myData1)

#Imported Sandiego vaccination dataset
myData2 <- read.csv(file = file.path(myDataLocation,"California count data_vaccination-new.csv"),header = TRUE)

str(myData1)
str(myData2)

#merge two datasets
newData_merged<- left_join(myData1, myData2, by=c("�..date","county","population","month","year"))

str(newData_merged)
summary(newData_merged)


# Some variables are dropped because it has cumulative cases,deaths, applied cumulative list of pfizer_doses, moderna_doses and Johnson and johnson doses.
# Those variables are removed from the analysis.

# drop columns
newData_merged = subset(newData_merged, select = -c(reported_cases,reported_tests,reported_deaths,cumulative_cases,cumulative_deaths,fips,cumulative_total_tests,cumulative_positive_tests,cumulative_reported_cases,cumulative_reported_deaths,doses_administered,pfizer_doses,moderna_doses,jj_doses,partially_vaccinated,at_least_one_dose,fully_vaccinated,partially_vaccinated_percent,at_least_one_dose_percent,fully_vaccinated_percent))

str(newData_merged)
summary(newData_merged)


# Check correlation between independent and dependent variables.
cor.test(new_fully_vaccinated ~ deaths, data=newData_merged)
cor.test(new_at_least_one_dose ~ deaths, data=newData_merged)
cor.test(new_partially_vaccinated ~ deaths, data= newData_merged)

#Shapiro test to check data normalization. 

# How do you interpret Shapiro-Wilk results?
#value of the Shapiro-Wilk Test is greater than 0.05, the data is normal. 
#If it is below 0.05, the data significantly deviate from a normal distribution.
shapiro.test(newData_merged$deaths)
shapiro.test(newData_merged$new_fully_vaccinated)
shapiro.test(newData_merged$new_partially_vaccinated)
shapiro.test(newData_merged$new_at_least_one_dose)

# create a function to normalize variables

normalize<- function(x){return((x - min(x,na.rm= TRUE)) / (max(x,na.rm=TRUE)-min(x,na.rm = TRUE)))}

str(newData_merged)
class(newData_merged)

#Apply normalize function to the dataset
norm_data= as.data.frame(apply(newData_merged[6:16],2,normalize))
str(norm_data)

#Adding Correlation coefficients to Heatmap
#install.packages("reshape2")
library(reshape2)

# creating correlation matrix
corr_mat <- round(cor(norm_data),2)
head(corr_mat)

# reduce the size of correlation matrix
melted_corr_mat <- melt(corr_mat)
print(melted_corr_mat)

# plotting the correlation heatmap
library(ggplot2)
ggplot(data = melted_corr_mat, aes(x=Var1, y=Var2,
                                   fill=value)) +
  geom_tile() +
  geom_text(aes(Var2, Var1, label = value),
            color = "black", size = 4)+ theme(axis.text.x = element_text(angle = 90))
str(melted_corr_mat)

# delete highly correlated variables. We are keeping our thresh hold 0.99.


cor_matrix <- cor(corr_mat)                      # Correlation matrix
cor_matrix

cor_matrix_rm <- cor_matrix                  # Modify correlation matrix
cor_matrix_rm[upper.tri(cor_matrix_rm)] <- 0
diag(cor_matrix_rm) <- 0
cor_matrix_rm
print(cor_matrix_rm)


summary(cor_matrix_rm)
data_new <- norm_data[ , !apply(cor_matrix_rm,    # Remove highly correlated variables
                                2,
                                function(x) any(x > 0.99))]
head(data_new)                               # Print updated data frame
str(data_new)
summary(data_new)

# Multilinear regression model for reject or accept the null hypothesis.
model  <- lm(deaths ~ new_at_least_one_dose + new_fully_vaccinated, data = data_new)
summary(model)

#load car package
library(car)

#produce added variable plots
avPlots(model)

scatterplot(deaths~new_at_least_one_dose, data = data_new)
scatterplot(deaths~new_fully_vaccinated, data = data_new)

#Calculate root mean square error
sqrt(mean((data_new$death - predict(model))^2))        # Calculate MSE


# Export cleaned data to CSV file  format
write.table(norm_data,file="California county normalized dataset.csv",row.names=F,sep = ",")

write.table(newData_merged,file="California county unnormalized dataset.csv",row.names=F,sep = ",")


